coin_smw = love.audio.newSource("sounds/coin.ogg", "stream")
