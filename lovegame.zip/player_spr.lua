--aqui cargaré los sprites de los personajes

--smw
smw_mario_small_stand = love.graphics.newImage("graphics/player/smw/mario/small/mario_stand.png")
smw_mario_small_stand:setFilter("nearest", "nearest")