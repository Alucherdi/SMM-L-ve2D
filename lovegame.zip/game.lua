gamestate = "init"
time = 400
coin = 0
points = 0
red_coins = 0
style = 3
bg = 1
--no sabía cómo ponerle
-- con esto trataré de controlar los niveles, si es vertical o horizontal 
level_long = 1