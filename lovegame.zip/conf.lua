function love.conf(t)
    t.identity = "smml2de"--identidad del almacenamiento interno, osea que hací saldrá xd
    t.version = "11.3"
    t.accelerometerjoystick = false
    t.externalstorage = true
 
    t.window.title = "super Mario maker love2d edition"--titulo o nombre del juego en la ventana
    t.window.icon = nil
    t.window.width = 800
    t.window.height = 600
    t.window.fullscreen = true
end