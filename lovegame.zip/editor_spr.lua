--cargar sprites del editor
barra1 = love.graphics.newImage("graphics/editor/1.png")
cursor = love.graphics.newImage("graphics/editor/cursor.png")
play_lvl_editor = love.graphics.newImage("graphics/editor/play.png")